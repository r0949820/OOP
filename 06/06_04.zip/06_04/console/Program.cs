﻿using models;
using System;
using System.Collections.Generic;

namespace console
{
    class Program
    {
        static void Main(string[] args)
        {
            
            Console.WriteLine("0. Donut");
            Console.WriteLine("1. Koffie");
            Console.WriteLine();
            Console.Write("Geef een optie op: ");
            string keuze = Console.ReadLine().ToLower();

            if (keuze == "donut")
            {
                List<string> siropen = FileOperations.LeesOpties(FileOperations.BestandSiropen);
                List<string> toppings = FileOperations.LeesOpties(FileOperations.BestandToppings);
                List<string> glazuren = FileOperations.LeesOpties(FileOperations.BestandGlazuren);
                List<string> vullingen = FileOperations.LeesOpties(FileOperations.BestandVullingen);

                Console.WriteLine();
                Console.WriteLine("0. Geen");
                for (int i = 0; i < siropen.Count; i++)
                {
                    Console.WriteLine($"{i + 1}. {siropen[i]}");
                }
                Console.WriteLine();
                Console.Write("Kies een siroop: ");
                int siroopKeuze = int.Parse(Console.ReadLine());

                Console.WriteLine();
                Console.WriteLine("0. Geen");
                for (int i = 0; i < toppings.Count; i++)
                {
                    Console.WriteLine($"{i + 1}. {toppings[i]}");
                }
                Console.WriteLine();
                Console.Write("Kies een topping: ");
                int toppingKeuze = int.Parse(Console.ReadLine());

                Console.WriteLine();
                Console.WriteLine("0. Geen");
                for (int i = 0; i < glazuren.Count; i++)
                {
                    Console.WriteLine($"{i + 1}. {glazuren[i]}");
                }
                Console.WriteLine();
                Console.Write("Kies een glazuur: ");
                int glazuurKeuze = int.Parse(Console.ReadLine());

                Console.WriteLine();
                Console.WriteLine("0. Geen");
                for (int i = 0; i < vullingen.Count; i++)
                {
                    Console.WriteLine($"{i + 1}. {vullingen[i]}");
                }
                Console.WriteLine();
                Console.Write("Kies een vulling: ");
                int vullingKeuze = int.Parse(Console.ReadLine());
                
                Donut donut = new Donut(siropen[siroopKeuze - 1], toppings[toppingKeuze - 1], glazuren[glazuurKeuze - 1], vullingen[vullingKeuze -1]);
                Console.WriteLine();
                Console.WriteLine("Bedankt voor uw bestelling!");
                Console.WriteLine();
                Console.WriteLine("Uw bestelling:");
                Console.WriteLine(donut.ToonOverzicht());
            }
            else if (keuze == "koffie")
            {
                List<string> siropen = FileOperations.LeesOpties(FileOperations.BestandSiropen);
                List<string> toppings = FileOperations.LeesOpties(FileOperations.BestandToppings);
                List<string> smaken = FileOperations.LeesOpties(FileOperations.BestandSmaken);

                Console.WriteLine();
                Console.WriteLine("0. Geen");
                for (int i = 0; i < siropen.Count; i++)
                {
                    Console.WriteLine($"{i + 1}. {siropen[i]}");
                }
                Console.WriteLine();
                Console.Write("Kies een siroop: ");
                int siroopKeuze = int.Parse(Console.ReadLine());

                Console.WriteLine();
                Console.WriteLine("0. Geen");
                for (int i = 0; i < toppings.Count; i++)
                {
                    Console.WriteLine($"{i + 1}. {toppings[i]}");
                }
                Console.WriteLine();
                Console.Write("Kies een topping: ");
                int toppingKeuze = int.Parse(Console.ReadLine());

                Console.WriteLine();
                Console.WriteLine("0. Geen");
                for (int i = 0; i < smaken.Count; i++)
                {
                    Console.WriteLine($"{i + 1}. {smaken[i]}");
                }
                Console.WriteLine();
                Console.Write("Kies een smaak: ");
                int smakenKeuze = int.Parse(Console.ReadLine());
                Console.WriteLine();
                Console.Write("Wenst u slagroom: ");
                string slagroom = Console.ReadLine();
                bool metSlagroom = (slagroom.ToLower() == "ja");
                

                Koffie koffie = new Koffie(siropen[siroopKeuze - 1], toppings[toppingKeuze - 1], smaken[smakenKeuze - 1], metSlagroom);
                Console.WriteLine();
                Console.WriteLine("Bedankt voor uw bestelling!");
                Console.WriteLine();
                Console.WriteLine("Uw bestelling:");
                Console.WriteLine(koffie.ToonOverzicht());
            }
            }
    }
}
