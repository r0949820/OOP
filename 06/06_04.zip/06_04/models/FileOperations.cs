﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace models
{
    public static class FileOperations
    {
        public static string BestandSiropen = "siropen.txt";
        public static string BestandToppings = "toppings.txt";
        public static string BestandGlazuren = "glazuren.txt";
        public static string BestandVullingen = "vullingen.txt";
        public static string BestandSmaken = "smaken.txt";

        public static List<string> LeesOpties(string bestandsnaam)
        {
            List<string> opties = new List<string>();

            try
            {
                using (StreamReader sr = new StreamReader(bestandsnaam))
                {
                    string lijn;
                    while ((lijn = sr.ReadLine()) != null)
                    {
                        opties.Add(lijn);
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Er is een fout opgetreden bij het lezen van het bestand: " + ex.Message);
            }

            return opties;
        }
        }
}
